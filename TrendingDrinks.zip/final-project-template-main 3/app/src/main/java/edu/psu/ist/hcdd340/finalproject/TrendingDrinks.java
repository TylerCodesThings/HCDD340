package edu.psu.ist.hcdd340.finalproject;

class Drink {

    final private String drinkName;
    final private int profileImage;
    final private String drinkCost;


    public Drink(String drinkName, int profileImage, String drinkCost) {
        this.drinkName = drinkName;
        this.drinkCost = drinkCost;
        this.profileImage = profileImage;
    }


    public String getDrinkName() {
        return drinkName;
    }

    public String getDrinkCost() { return drinkCost; }


    public int getProfileImage() {
        return profileImage;
    }
}

