package edu.psu.ist.hcdd340.finalproject;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class TrendingDrinkActivity extends AppCompatActivity {
    private final Drink[] TRENDING_DRINKS = {
            new Drink("Caramel Macchiato", R.drawable.caramel_macchiato, "$4.49"),
            new Drink("Chai Tea Latte", R.drawable.chai_tea_latte, "$3.69")
    };

    private RecyclerView mRecyclerView;
    private DrinkListAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drinks_list);

        mRecyclerView = findViewById(R.id.recycler_view_drinks);
        mAdapter = new DrinkListAdapter(this, TRENDING_DRINKS);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}
