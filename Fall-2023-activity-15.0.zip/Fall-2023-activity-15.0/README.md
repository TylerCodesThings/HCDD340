# HCDD 340 (Fall 2022)
Class repository for Fall 2022 (Canvas: https://psu.instructure.com/courses/2212211)
