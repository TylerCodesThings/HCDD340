package edu.psu.ist.hcdd340.finalproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.snackbar.Snackbar;

import java.util.HashMap;
import java.util.Map;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    public static final String SHARED_PREF_NAME = "PERFECT_CUP";
    public static final String TEMP_KEY1 = "HOT OR COLD";
    public static final String TEMP_KEY2 = "COFFEE OR TEA";

    private SharedPreferences sharedPreferences;

    private final Map<String, String> drinkMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //create hot and cold buttons
        Button hotButton = findViewById(R.id.hot_button);
        hotButton.setOnClickListener(this);

        Button coldButton = findViewById(R.id.cold_button);
        coldButton.setOnClickListener(this);

        //Hide coffee and tea buttons
        findViewById(R.id.coffee_button).setVisibility(View.GONE);
        findViewById(R.id.tea_button).setVisibility(View.GONE);

        Button teaButton = findViewById(R.id.tea_button);
        teaButton.setOnClickListener(this);

        Button coffeeButton = findViewById(R.id.coffee_button);
        coffeeButton.setOnClickListener(this);

        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);

        populateDrinkMap();
    }

    private void populateDrinkMap() {
        drinkMap.put("HotCoffee", "Cappuccino");
        drinkMap.put("ColdCoffee", "Iced Caramel Macchiato");
        drinkMap.put("ColdTea", "Peach Green Tea");
        drinkMap.put("HotTea", "Hot Chai Latte");
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.hot_button) {
            saveTempResponse("Hot");

            //removes hot and cold buttons
            findViewById(R.id.hot_button).setVisibility(View.GONE);
            findViewById(R.id.cold_button).setVisibility(View.GONE);

            //shows coffee and tea buttons
            findViewById(R.id.coffee_button).setVisibility(View.VISIBLE);
            findViewById(R.id.tea_button).setVisibility(View.VISIBLE);
        } else if (id == R.id.cold_button) {
            saveTempResponse("Cold");

            findViewById(R.id.hot_button).setVisibility(View.GONE);
            findViewById(R.id.cold_button).setVisibility(View.GONE);

            findViewById(R.id.coffee_button).setVisibility(View.VISIBLE);
            findViewById(R.id.tea_button).setVisibility(View.VISIBLE);
        }

        if (id == R.id.coffee_button) {
            saveTypeResponse("Coffee");
            showAlertDialog();
        } else if (id == R.id.tea_button) {
            saveTypeResponse("Tea");
            showAlertDialog();
        }
    }

    private void showAlertDialog() {
        String tempResponse = sharedPreferences.getString(TEMP_KEY1, "");
        String typeResponse = sharedPreferences.getString(TEMP_KEY2, "");


        String drink = drinkMap.get(tempResponse + typeResponse);
        if (drink == null) {
            drink = "Iced Caramel Macchiato"; // Default drink
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Your drink: " + "\n" + drink )
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void saveTempResponse(String response) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(TEMP_KEY1, response);
        editor.apply();
    }

    private void saveTypeResponse(String response) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(TEMP_KEY2, response);
        editor.apply();
    }


}