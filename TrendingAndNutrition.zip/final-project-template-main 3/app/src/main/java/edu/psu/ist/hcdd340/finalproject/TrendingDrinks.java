package edu.psu.ist.hcdd340.finalproject;

class Drink {

    private final String drinkName;
    private final int profileImage;
    private final String drinkCost;
    private final String carbs;
    private final String proteins;
    private final String fats;
    private final String sugar;

    public Drink(String drinkName, int profileImage, String drinkCost, String carbs, String proteins, String fats, String sugar) {
        this.drinkName = drinkName;
        this.drinkCost = drinkCost;
        this.profileImage = profileImage;
        this.carbs = carbs;
        this.proteins = proteins;
        this.fats = fats;
        this.sugar = sugar;
    }

    public String getDrinkName() {
        return drinkName;
    }

    public String getDrinkCost() {
        return drinkCost;
    }

    public int getProfileImage() {
        return profileImage;
    }

    public String getCarbs() {
        return carbs;
    }

    public String getProteins() {
        return proteins;
    }

    public String getFats() {
        return fats;
    }

    public String getSugar() {
        return sugar;
    }
}