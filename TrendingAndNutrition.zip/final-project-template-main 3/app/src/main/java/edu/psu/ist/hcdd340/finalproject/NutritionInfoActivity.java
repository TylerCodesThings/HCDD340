package edu.psu.ist.hcdd340.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class NutritionInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nutrition_info);

        // Get data from intent extras
        Intent intent = getIntent();
        String drinkName = intent.getStringExtra("drinkName");
        String nutritionInfo = intent.getStringExtra("nutritionInfo");
        String carbs = intent.getStringExtra("carbs");
        String proteins = intent.getStringExtra("proteins");
        String fats = intent.getStringExtra("fats");
        String sugar = intent.getStringExtra("sugar");
        // Update UI elements with data
        TextView drinkNameTextView = findViewById(R.id.drink_name_textview);
        TextView nutritionInfoTextView = findViewById(R.id.nutrition_info_textview);
        TextView carbsTextView = findViewById(R.id.carbs_textview);
        TextView proteinsTextView = findViewById(R.id.proteins_textview);
        TextView fatsTextView = findViewById(R.id.fats_textview);
        TextView sugarTextView = findViewById(R.id.sugar_textview);

        drinkNameTextView.setText(drinkName);
        nutritionInfoTextView.setText(nutritionInfo);
        carbsTextView.setText("Carbs: " + carbs);
        proteinsTextView.setText("Proteins: " + proteins);
        fatsTextView.setText("Fats: " + fats);
        sugarTextView.setText("Sugar: " + sugar);
    }
}