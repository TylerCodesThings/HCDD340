package edu.psu.ist.hcdd340.finalproject;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class TrendingDrinksActivity extends AppCompatActivity {

    private final Drink[] TRENDING_DRINKS = {
            new Drink("Caramel Macchiato", R.drawable.caramel_macchiato, "$4.89", "20g", "5g", "8g", "15g"),
            new Drink("Chai Tea Latte", R.drawable.chai_tea_latte, "$3.25", "10g", "0g", "0g", "10g"),
            new Drink("Strawberry Smoothie", R.drawable.strawberry_smoothie, "$5.35", "23g", "0g", "2g", "15g"),
            new Drink("Sugar Cookie Latte", R.drawable.sugar_cookie_latte, "$4.75", "30g", "4g", "3g", "20g"),
            new Drink("Pink Drink", R.drawable.pink_drink, "$5.15", "10g", "8g", "7g", "4g")
            // Add more drinks as needed
    };

    private RecyclerView mRecyclerView;
    private DrinkListAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drinks_list);

        mRecyclerView = findViewById(R.id.recycler_view_drinks);
        mAdapter = new DrinkListAdapter(this, TRENDING_DRINKS);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}