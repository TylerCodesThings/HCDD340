package edu.psu.ist.hcdd340.finalproject;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class DrinkListAdapter extends RecyclerView.Adapter<DrinkListAdapter.DrinkViewHolder> {

    private final Drink[] mDrinkList;
    private final LayoutInflater mInflater;

    public DrinkListAdapter(Context context, Drink[] mDrinkList) {
        this.mDrinkList = mDrinkList;
        mInflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public DrinkViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View mItemView = mInflater.inflate(R.layout.drink_list_item, parent, false);
        return new DrinkViewHolder(mItemView);
    }

    @Override
    public void onBindViewHolder(@NonNull DrinkViewHolder holder, int position) {
        Drink drink = mDrinkList[position];
        holder.drinkNameView.setText(drink.getDrinkName());
        holder.drinkImageView.setImageResource(drink.getProfileImage());
        holder.drinkCostView.setText(drink.getDrinkCost()); // Set drink cost
        holder.nutritionInfoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), NutritionInfoActivity.class);
                intent.putExtra("drinkName", drink.getDrinkName());
                intent.putExtra("carbs", drink.getCarbs());
                intent.putExtra("proteins", drink.getProteins());
                intent.putExtra("fats", drink.getFats());
                intent.putExtra("sugar", drink.getSugar());
                intent.putExtra("drinkCost", drink.getDrinkCost()); // Pass drink cost
                v.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mDrinkList.length;
    }

    class DrinkViewHolder extends RecyclerView.ViewHolder {

        private final TextView drinkNameView;
        private final ImageView drinkImageView;
        private final TextView drinkCostView;
        private final Button nutritionInfoButton;

        public DrinkViewHolder(@NonNull View itemView) {
            super(itemView);
            drinkImageView = itemView.findViewById(R.id.drink_list_image_id);
            drinkNameView = itemView.findViewById(R.id.drink_list_name_id);
            drinkCostView = itemView.findViewById(R.id.drink_cost_textview); // Initialize drink cost TextView
            nutritionInfoButton = itemView.findViewById(R.id.nutrition_info_button);
        }
    }
}