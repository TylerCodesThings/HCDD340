package edu.psu.ist.hcdd340.finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.snackbar.Snackbar;



public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    public static final String SHARED_PREF_NAME = "PERFECT_CUP";
    public static final String TEMP_KEY = "HOT OR COLD";

    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button hotButton = findViewById(R.id.hot_button);
        hotButton.setOnClickListener(this);

        Button coldButton = findViewById(R.id.cold_button);
        coldButton.setOnClickListener(this);

        findViewById(R.id.coffee_button).setVisibility(View.GONE); // Hide the Coffee button
        findViewById(R.id.tea_button).setVisibility(View.GONE); //Hide the Tea button

        Button teaButton = findViewById(R.id.tea_button);
        teaButton.setOnClickListener(this);

        Button coffeeButton = findViewById(R.id.coffee_button);
        teaButton.setOnClickListener(this);

        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.hot_button) {
            saveResponse("Hot");
            //addNewButtons("Coffee", "Tea");
            findViewById(R.id.hot_button).setVisibility(View.GONE); // Hide the Hot button
            findViewById(R.id.cold_button).setVisibility(View.GONE);// Hide the Cold button

            findViewById(R.id.coffee_button).setVisibility(View.VISIBLE);
            findViewById(R.id.tea_button).setVisibility(View.VISIBLE);
        } else if (id == R.id.cold_button) {
            saveResponse("Cold");
            //addNewButtons("Coffee", "Tea");
            findViewById(R.id.hot_button).setVisibility(View.GONE);
            findViewById(R.id.cold_button).setVisibility(View.GONE);

            findViewById(R.id.coffee_button).setVisibility(View.VISIBLE);
            findViewById(R.id.tea_button).setVisibility(View.VISIBLE);
        }
    }

    private void saveResponse(String response){
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(TEMP_KEY, response);
        editor.apply();
    }
    private void addNewButtons(String buttonText1, String buttonText2) {
        Button coffeeButton = new Button(this);
        coffeeButton.setText(buttonText1);
        coffeeButton.setId(View.generateViewId());

        Button teaButton = new Button(this);
        teaButton.setText(buttonText2);
        teaButton.setId(View.generateViewId());

        ConstraintLayout layout = findViewById(R.id.mainConstraintLayout);

        ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(
                ConstraintLayout.LayoutParams.WRAP_CONTENT,
                ConstraintLayout.LayoutParams.WRAP_CONTENT
        );

        layout.addView(coffeeButton, params);
        layout.addView(teaButton, params);

        ConstraintSet constraintSet = new ConstraintSet();
        constraintSet.clone(layout);

        // Set constraints for the Coffee button
        constraintSet.connect(coffeeButton.getId(), ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START, dpToPx(16));
        constraintSet.connect(coffeeButton.getId(), ConstraintSet.TOP, R.id.hot_button, ConstraintSet.BOTTOM, dpToPx(16));

        // Set constraints for the Tea button
        constraintSet.connect(teaButton.getId(), ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START, dpToPx(16));
        constraintSet.connect(teaButton.getId(), ConstraintSet.TOP, coffeeButton.getId(), ConstraintSet.BOTTOM, dpToPx(16));

        constraintSet.applyTo(layout);
    }

    // Utility function to convert dp to pixels
    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

}