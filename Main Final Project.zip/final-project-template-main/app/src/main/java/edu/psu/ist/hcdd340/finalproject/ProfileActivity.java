package edu.psu.ist.hcdd340.finalproject;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.android.material.snackbar.Snackbar;

public class ProfileActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        ImageView openEye = findViewById(R.id.open_eye);
        openEye.setOnClickListener(this);

        ImageView closedEye = findViewById(R.id.closed_eye);
        closedEye.setOnClickListener(this);
        findViewById(R.id.closed_eye).setVisibility(View.GONE);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_profile, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int menuId = item.getItemId();
        if (menuId == R.id.menu_home) {
            Intent homeIntent = new Intent(this, MainActivity.class);
            startActivity(homeIntent);
            return true;
        }else if(menuId == R.id.menu_login) {
            Intent loginIntent = new Intent(this, LoginActivity.class);
            startActivity(loginIntent);
            return true;
        }if(menuId == R.id.menu_trending){
            Intent trendingIntent = new Intent(this, TrendingDrinkActivity.class);
            startActivity(trendingIntent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void onClick(View view) {
        int id = view.getId();

        //Shows history on profile page. Eye icon is open
        if (id == R.id.open_eye) {
            findViewById(R.id.open_eye).setVisibility(View.GONE);
            findViewById(R.id.closed_eye).setVisibility(View.VISIBLE);
            Snackbar.make(findViewById(id),
                    "History hidden from friends",
                    Snackbar.LENGTH_LONG).show();
            //Hides history on profile page. Eye icon closed
        } else if  (id == R.id.closed_eye) {
            findViewById(R.id.open_eye).setVisibility(View.VISIBLE);
            findViewById(R.id.closed_eye).setVisibility(View.INVISIBLE);
            Snackbar.make(findViewById(id),
                    "History visible to friends",
                    Snackbar.LENGTH_LONG).show();
        }
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }
}
